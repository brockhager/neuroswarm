#!/usr/bin/env bash
echo "========================================"
echo "Starting gateway-node"
echo "========================================"
echo ""
echo "Port: 8080"
echo ""
export PORT=8080
node server.js
