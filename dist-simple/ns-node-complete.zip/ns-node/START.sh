#!/usr/bin/env bash
echo "========================================"
echo "Starting ns-node"
echo "========================================"
echo ""
echo "Port: 3000"
echo ""
export PORT=3000
node server.js
