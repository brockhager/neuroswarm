#!/usr/bin/env node
"use strict";
console.error('publishUpdate.js (CommonJS) is deprecated. Please use publishUpdate.mjs (ESM).');
process.exit(1);
