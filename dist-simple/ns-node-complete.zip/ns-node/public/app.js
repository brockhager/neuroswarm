let messageHistory = [];

// Load chat history on page load
window.addEventListener('DOMContentLoaded', async () => {
  await loadHistory();
  scrollToBottom();
});

// Load chat history from server
async function loadHistory() {
  try {
    const response = await fetch('/history');
    const data = await response.json();

    if (data.messages && data.messages.length > 0) {
      const chatContainer = document.getElementById('chatContainer');
      // Remove welcome message
      chatContainer.innerHTML = '';

      data.messages.forEach(msg => {
        addMessageToUI(msg.role, msg.content, false);
      });
      messageHistory = data.messages;
    }
  } catch (error) {
    console.error('Failed to load history:', error);
  }
}

// Handle Enter key press
function handleKeyPress(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
}

// Quick question function
function askQuestion(question) {
  const input = document.getElementById('userInput');
  input.value = question;
  sendMessage();
}

// Send message
async function sendMessage() {
  const input = document.getElementById('userInput');
  const message = input.value.trim();

  if (!message) return;

  // Clear input
  input.value = '';
  input.style.height = 'auto';

  // Remove welcome message if present
  const welcomeMsg = document.querySelector('.welcome-message');
  if (welcomeMsg) {
    welcomeMsg.remove();
  }

  // Add user message to UI
  addMessageToUI('user', message);

  // Add loading indicator
  const loadingId = addLoadingIndicator();

  // Disable send button
  const sendBtn = document.querySelector('.send-btn');
  sendBtn.disabled = true;

  try {
    const response = await fetch('/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message })
    });

    const data = await response.json();

    // Remove loading indicator
    removeLoadingIndicator(loadingId);

    // Add assistant response
    if (data.reply) {
      addMessageToUI('assistant', data.reply);
    } else if (data.error) {
      addMessageToUI('assistant', `Error: ${data.error}`);
    }

  } catch (error) {
    removeLoadingIndicator(loadingId);
    addMessageToUI('assistant', 'Sorry, I encountered an error. Please try again.');
    console.error('Error:', error);
  } finally {
    sendBtn.disabled = false;
  }
}

// Add message to UI
function addMessageToUI(role, content, animate = true) {
  const chatContainer = document.getElementById('chatContainer');

  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${role}`;
  if (!animate) {
    messageDiv.style.animation = 'none';
  }

  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = role === 'user' ? '👤' : '🤖';

  const contentDiv = document.createElement('div');
  contentDiv.className = 'message-content';
  contentDiv.textContent = content;

  messageDiv.appendChild(avatar);
  messageDiv.appendChild(contentDiv);
  chatContainer.appendChild(messageDiv);

  scrollToBottom();
}

// Add loading indicator
function addLoadingIndicator() {
  const chatContainer = document.getElementById('chatContainer');

  const messageDiv = document.createElement('div');
  messageDiv.className = 'message assistant';
  messageDiv.id = 'loading-message';

  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = '🤖';

  const loadingDiv = document.createElement('div');
  loadingDiv.className = 'message-content';
  loadingDiv.innerHTML = `
        <div class="loading">
            <div class="loading-dot"></div>
            <div class="loading-dot"></div>
            <div class="loading-dot"></div>
        </div>
    `;

  messageDiv.appendChild(avatar);
  messageDiv.appendChild(loadingDiv);
  chatContainer.appendChild(messageDiv);

  scrollToBottom();

  return 'loading-message';
}

// Remove loading indicator
function removeLoadingIndicator(id) {
  const loadingMsg = document.getElementById(id);
  if (loadingMsg) {
    loadingMsg.remove();
  }
}

// Scroll to bottom of chat
function scrollToBottom() {
  const chatContainer = document.getElementById('chatContainer');
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

// Auto-resize textarea
const textarea = document.getElementById('userInput');
textarea.addEventListener('input', function () {
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});