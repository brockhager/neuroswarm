const messagesDiv = document.getElementById('messages');
const textInput = document.getElementById('text');
const sendBtn = document.getElementById('send');

function appendMsg(sender, content, cid, tx) {
  const d = document.createElement('div');
  d.className = 'msg';
  d.innerHTML = `<span class="sender">${sender}:</span> ${content}` + (cid ? `<div style="font-size:0.8rem;color:#666">CID: ${cid} ${tx ? '| ' + tx : ''}</div>` : '');
  messagesDiv.appendChild(d);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

async function sendMessage() {
  const text = textInput.value.trim();
  if (!text) return;
  appendMsg('You', text);
  textInput.value = '';

  try {
    const resp = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sender: 'local', content: text })
    });
    const json = await resp.json();
    appendMsg(json.sender || 'agent', json.content, json.cid, json.txSignature);
  } catch (err) {
    appendMsg('system', 'Error sending message');
  }
}

sendBtn.addEventListener('click', sendMessage);
textInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendMessage();
});

// load history
(async () => {
  try {
    const resp = await fetch('/history');
    const h = await resp.json();
    h.forEach(m => appendMsg(m.direction === 'in' ? m.sender : m.sender, m.content, m.cid, m.txSignature));
  } catch (e) {
    console.warn('No history loaded');
  }
})();